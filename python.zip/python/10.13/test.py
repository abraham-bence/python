while True:
    print("#############################")
    num = int(input("Szám: "))

    while num!=1:
        print(num)
        if num % 2 != 0:
            num = num* 3 + 1
        else:
            num = num / 2