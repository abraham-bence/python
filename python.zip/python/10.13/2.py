"""
for i in range(0,100):
    print("*",end=" ")
"""
""""""
num = int(input("Szám:"))
karakter = input("Karakter:")
for i in range(0,num):
    print(karakter, end=" ")


