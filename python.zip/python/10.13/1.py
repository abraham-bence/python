"""
print("###########")

for i in range(1,21):
    print(i , i**2)
"""
"""
for i in range(99,-1,-1):
    if i % 3 == 0:
        print(i)
"""
"""
for i in range(101,49,-1):
    if i % 5 == 0:
        print(i , i*2)
"""

range2 = 1000
for i in range(1,range2):
    print(i, end=", ")
    if i == range2 - 1:
        print(".")

"""
for i in range(1000,1,-3):
    print(i)
"""
