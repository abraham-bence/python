#1. feladat
print("1. feladat")
print("Szia, hogy hívnak?")
name = input()
print("Szia", name +"! :D")

#2. feladat
print("2. feladat")
tank = int(input("Hány literes az autó tankja?"))
distance = float(input("Hány kilómétert ment az autó teli tankkal?")) / 100
print("Az átlagos fogyasztása", round(tank / distance, 2), "liter.")
print("Egy teli tank benzin", tank * 489 , "Forint.")

#3. feladat
print("3. feladat")
forint = int(input("Adjon meg egy Forint összeget!"))

usd = forint / 308
euro =  forint / 359
frank = forint / 331

print("USD:", round(usd, 2))
print("EURO:", round(euro, 2))
print("CHF:" , round(frank, 2))

#4. feladat
import math
print("4. feladat")
number = float(input("Adjon meg egy egész számot!"))

print("A megadott szám a", math.floor(number) ," és a", math.ceil(number) ,"egész számok között van, és ezek közül a(z)", round(number) ,"számhoz van közelebb." "A szám törtrésze:", number-math.floor(number))
print("A szám egész része:", math.floor(number))
print("A szám törtrésze:", number-math.floor(number))
print("A szám négyzete:", pow(number, 2))