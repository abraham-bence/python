import random
while True:
    x = int(input("Az intervallum eleje: "))
    y = int(input("Az intervallum vége: "))

    for i in range(0,10):
        print(random.randint(x,y))
    