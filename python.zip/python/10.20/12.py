
num = int(input("Hány számot írjunk ki?")) - 2 

x = 0
y = 1
print(f"{x}\n{y}")

for i in range(0,num):
    z = x + y
    x = y
    y = z
    print(z)