
num = int(input("Hány számot?")) + 1

for y in range(1,num):
    dealer = 0
    for i in range(1,y+1):
        if y % i == 0:
            dealer = dealer + 1
    if dealer == 2:
        print(y)