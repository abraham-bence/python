num = float(input("Kérek egy számot!"))

if 1<num<9:
    print("Benne van a {1;9} intervallumban.")

else:
    print("Nincs benne a {1;9} intervallumban.")