char = ord(input("Kérek egy karaktert!"))

print(char)
if 48 <= char <= 57:
    print("Ez egy szám.")
elif 65 <= char <= 90:
    print("ez egy nagy betű")
    print(chr(char + 32))
elif 97 <= char <= 122:
    print("Ez egy kis betű")
    print(chr(char - 32))

