aOldal = int(input("a oldal:"))
bOldal = int(input("b oldal:"))

if aOldal==bOldal:
    print("Ez egy négyzet")
else:
    print("Ez egy téglalap")