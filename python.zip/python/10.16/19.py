hiányzások = int(input("Igazolatlan hiányzások száma:"))

if hiányzások == 0:
    print("Jeles")
elif hiányzások <= 3:
    print("jó")
elif hiányzások <=9:
    print("közepes")
elif hiányzások == 10:
    print("elégséges")
else:
    year = int(input("A diák életkora:"))
    if year < 18:
        print("Szülő értesítése szükésges!")
    else:
        print("Felszólítás szükséges!")