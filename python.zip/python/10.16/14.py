num1 = int(input("Első szám:"))
num2 = int(input("Második szám:"))

if num1 < num2:
    print("Az második szám nagyobb mint a első.")
elif num1 > num2:
    print("A első szám nagyobb mint a második.")
else:
    print("A két szám egyenlő.")