a = int(input("a oldal:"))
b = int(input("b oldal:"))
c = int(input("c oldal:"))

if a==b==c:
    print("Ez egy szabályos háromszög")
else:
    print("Ez nem szabályos háromszög")