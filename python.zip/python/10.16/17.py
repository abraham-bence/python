maxPont = int(input("A dolgozat max ponszáma:"))
elértPont = float(input("Elért pontszám:"))

százalék = elértPont / maxPont * 100

print(százalék)
if százalék <= 42:
    print("elégtelen")
elif százalék <= 57:
    print("elégséges")
elif százalék <= 72:
    print("közepes")
elif százalék <= 87:
    print("jó")
elif százalék <= 100:
    print("jeles")