x = int(input("x koordináta:"))
y = int(input("y koordináta:"))

if x>0 and y>0:
    print("1. síknegyed")
elif x<0 and y>0:
    print("2. síknegyed")
elif x<0 and y<0: 
    print("3. síknegyed")
elif x<0 and y>0:
    print("4. síknegyed")
else:
    print("Egyik síknegyedben sincs")