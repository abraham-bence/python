temp = int(input("A víz hőmérséklete:"))

if temp >= 0:
    print("A víz folyékony.")
else:
    print("A víz szilárd")