import math

num = int(input("Kérek egy valós szamot!"))

if num>0:
    print("Értelmezve van.")
else:
    print("Nincs értelmezve")