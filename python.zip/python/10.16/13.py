num = int(input("Kérek egy számot:"))

if num < 0:
    print("A szám negatív előjelű.")

elif num > 0:
    print("A szám pozitív előjelű.")
else:
    print("A szám 0.")