num1 = int(input("Első szám: "))
num2 = int(input("Második szám: "))

if num2 == 0 :
    print("ERROR")