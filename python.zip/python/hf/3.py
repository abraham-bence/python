num = int(input("Kérek egy egész számot:")) 

if num % 10==0 :
    print("Osztható tízzel")