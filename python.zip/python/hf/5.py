
num = int(input("Egy három jegyű szám: "))

számjegy3 = int(num % 10)
num2 = num - számjegy3
num3 = num2 / 10

számjegy2 = int(num3 % 10)
num5 = num3 - számjegy2
számjegy1 = int(num5 / 10)


print(számjegy1, számjegy2, számjegy3)