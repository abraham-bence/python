print("\tA\t|\tB\t|\tA and B")

A = False
B = False

print("-------------------------------------------------")
print(f"\t{A}\t|\t{B}\t|\t{A and B}\t|")
A = True
B = False
print("-------------------------------------------------")
print(f"\t{A}\t|\t{B}\t|\t{A and B}\t|")
A = False
B= True
print("-------------------------------------------------")
print(f"\t{A}\t|\t{B}\t|\t{A and B}\t|")
A = True
B = True
print("-------------------------------------------------")
print(f"\t{A}\t|\t{B}\t|\t{A and B}\t|")

#or
print("-------------------------------------------------")

print("\tA\t|\tB\t|\tA or B")

A = False
B = False

print("-------------------------------------------------")
print(f"\t{A}\t|\t{B}\t|\t{A or B}\t|")
A = True
B = False
print("-------------------------------------------------")
print(f"\t{A}\t|\t{B}\t|\t{A or B}\t|")
A = False
B= True
print("-------------------------------------------------")
print(f"\t{A}\t|\t{B}\t|\t{A or B}\t|")
A = True
B = True
print("-------------------------------------------------")
print(f"\t{A}\t|\t{B}\t|\t{A or B}\t|")