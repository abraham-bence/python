num = int(input("Kérek egy számot:"))

if num > 0 :
    print("A szám +")
else :
    print("Nem pozitív")
print("Ez már elágazáson kívül van")